@javax.xml.bind.annotation.XmlSchema(namespace = "http://server/")
package week.pkg08.b.client;
